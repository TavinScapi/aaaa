from django.apps import AppConfig


class FormularioAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'formulario_app'
