from django import forms
from .models import Formulario

class FormularioForm(forms.ModelForm):
    class Meta:
        model = Formulario
        fields = [
            'nome', 'idade', 'telefone', 'endereco', 'bolo_favorito',
            'confetes', 'pagamento', 'massa', 'tamanho_preferido', 'observacoes'
        ]
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'idade': forms.NumberInput(attrs={'class': 'form-control'}),
            'telefone': forms.NumberInput(attrs={'class': 'form-control'}),
            'endereco': forms.TextInput(attrs={'class': 'form-control'}),
            'bolo_favorito': forms.Select(attrs={'class': 'form-control'}),
            'confetes': forms.Select(attrs={'class': 'form-control'}),
            'pagamento': forms.RadioSelect(attrs={'class': 'form-radio'}),
            'massa': forms.RadioSelect(
                choices=Formulario.MASSA_CHOICES, attrs={'class': 'form-radio'}
            ),
            'tamanho_preferido': forms.RadioSelect(
                choices=Formulario.TAMANHO_CHOICES, attrs={'class': 'form-radio'}
            ),
            'observacoes': forms.Textarea(attrs={'class': 'form-control'}),
        }

