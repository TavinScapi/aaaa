from django.db import models

class Formulario(models.Model):
    BOLO_FAV_CHOICES = [
        ('Chocolate', 'Bolo de Chocolate'),
        ('Ninho', 'Bolo de Ninho'),
        ('Morango', 'Bolo de Morango'),
        ('Abacaxi', 'Bolo de Abacaxi'),
    ]

    CONFETES_CHOICES = [
        ('Granulado', 'Granulado'),
        ('BomBom', 'BomBom'),
        ('Estrelinhas', 'Estrelinhas'),
        ('Bis','Bis')
    ]

    PAGAMENTOS_CHOICES = [
        ('Dinheiro', 'Dinheiro'),
        ('Cartão Credito','Cartão Credito'),
        ('Cartão Debito','Cartão Debito'),
        ('Cartão Alimentação','Cartão Alimentação')
    ]

    MASSA_CHOICES = [
        ('Tradicinal','Tradicinal'),
        ('Chocolate','Chocolate')
    ]

    TAMANHO_CHOICES = [
        ('Pote','Pote'),
        ('500ml','500ml'),
        ('1kg','1kg'),
        ('2kg','2kg')
    ]

    nome = models.CharField(max_length=100)
    idade = models.IntegerField()
    telefone = models.CharField(max_length=20)
    endereco = models.CharField(max_length=200)
    bolo_favorito = models.CharField(
        max_length=20,
        choices=BOLO_FAV_CHOICES
    )
    confetes = models.CharField(
        max_length=20,
        choices=CONFETES_CHOICES
    )
    pagamento = models.CharField(
        max_length=20,
        choices=PAGAMENTOS_CHOICES
    )
    massa = models.CharField(
        max_length=20,
        choices=MASSA_CHOICES
    )
    tamanho_preferido = models.CharField(
        max_length=200,
        choices=TAMANHO_CHOICES
    )
    observacoes = models.TextField()

# Create your models here.
